import React, { useState } from "react";
import { View, StyleSheet, Button, Alert } from "react-native";
import ToDoList from "../components/ToDoList";
import ToDoForm from "../components/ToDoForm";
import MainLayout from "../layouts/MainLayout";

function HomeScreen({ navigation }) {
  const [tasks, setTasks] = useState(["Do laundry", "Go to gym", "Walk dog"]);

  const addTask = (newTask) => {
    const trimmedTask = newTask.trim();
    if (!trimmedTask) return;

    const isDuplicate = tasks.some(
      (existingTask) => existingTask.toLowerCase() === trimmedTask.toLowerCase()
    );

    if (isDuplicate) {
      Alert.alert("Duplicate Task", "This task already exists!");
      return;
    }

    setTasks((prevTasks) => [...prevTasks, trimmedTask]);
  };

  return (
    <MainLayout>
      <View style={styles.container}>
        <ToDoList tasks={tasks} />
        <ToDoForm addTask={addTask} />
        <Button
          title="Go to About"
          onPress={() => navigation.navigate("About")}
        />
      </View>
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#fff",
  },
  aboutButton: {
    backgroundColor: "#2196F3",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 10,
  },
  aboutButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
});

export default HomeScreen;
